package com.account.bean;

public  class AccountBean implements Comparable <AccountBean>{
	
	private int aid;
	private long mobile;
	private String accountholder;
	private double balance;
	public AccountBean() {
		
	}
	public AccountBean(int aid, long mobile, String accountholder, double balance) {
		super();
		this.aid = aid;
		this.mobile = mobile;
		this.accountholder = accountholder;
		this.balance = balance;
	}
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public String getAccountholder() {
		return accountholder;
	}
	public void setAccountholder(String accountholder) {
		this.accountholder = accountholder;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [aid=" + aid + ", mobile=" + mobile + ", accountholder=" + accountholder + ", balance="
				+ balance + "]";
	}
	@Override
	public int compareTo(AccountBean arg0) {
		// default sorting based on account number
		
		int diff=this.getAid()-arg0.getAid();
		if(diff>0)
			return 1;
		else if(diff<0)
			return -1;
		else 
			return 0;
		
	}
	
	
	

}
