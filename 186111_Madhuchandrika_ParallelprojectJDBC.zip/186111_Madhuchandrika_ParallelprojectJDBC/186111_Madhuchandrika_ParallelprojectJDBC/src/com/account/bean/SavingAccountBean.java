package com.account.bean;

public class SavingAccountBean extends AccountBean {
	private double interest;
	private final double MIN_Balance =1000.00;
	public SavingAccountBean() {
		// TODO Auto-generated constructor stub
	}
	public SavingAccountBean(int aid, int mobile, String accountholder, double balance) {
		super(aid, mobile, accountholder, balance);
		// TODO Auto-generated constructor stub
	}
	public double getInterest() {
		return interest;
	}
	public void setInterest() {
		this.interest = 0.04*super.getBalance();
	}
	@Override
	public String toString() {
		return super.toString()+"SavingAccount [interest=" + interest + "]";
	}
	
	
	

}
