package com.account.service;

import java.sql.SQLException;
import java.util.Map;

import com.account.bean.AccountBean;
import com.account.exception.InsuffecientFundException;

public interface AccountOperation {
	public boolean addAccount(AccountBean ob);
	public boolean updateAccount(AccountBean ob) throws SQLException ;
	public AccountBean findAccount(Long mobileno);
	public Map<Long,AccountBean> getAllAccounts() throws SQLException;
	public double TransferMoney(AccountBean from, AccountBean to,double amount) throws InsuffecientFundException, SQLException ; 
}
