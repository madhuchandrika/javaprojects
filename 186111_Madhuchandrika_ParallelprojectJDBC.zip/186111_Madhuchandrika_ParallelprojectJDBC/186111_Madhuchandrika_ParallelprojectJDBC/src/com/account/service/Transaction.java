package com.account.service;
import java.sql.SQLException;

import com.account.bean.AccountBean;
import com.account.exception.InsuffecientFundException;
public interface Transaction extends AccountOperation{
	
	public double withdraw(AccountBean ob, double amount) throws InsuffecientFundException, SQLException;
	public double Deposit(AccountBean ob, double amount) throws InsuffecientFundException, SQLException; 
	public double TransferMoney(AccountBean from, AccountBean to,double amount) throws InsuffecientFundException, SQLException; 
	
	public default void printStatment(AccountBean ob)
	{

		System.out.println("Statement for Account No. :- "+ob.getAid());
		System.out.println("Mobile No. :- "+ob.getMobile());
		System.out.println("AccountHolder Name :- "+ob.getAccountholder());
		System.out.println("Balance is :- "+ob.getBalance());
	}

}
