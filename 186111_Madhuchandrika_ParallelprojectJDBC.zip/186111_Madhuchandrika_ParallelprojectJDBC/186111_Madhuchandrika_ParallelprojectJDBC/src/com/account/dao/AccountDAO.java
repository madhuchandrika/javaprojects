package com.account.dao;
import java.sql.SQLException;
import java.util.Map;

import com.account.bean.*;
import com.account.exception.InsuffecientFundException;
public interface AccountDAO {
	
	public boolean addAccount(AccountBean ob);
	public boolean updateAccount(AccountBean ob) throws SQLException;
	public AccountBean findAccount(Long mobileno);
	public Map<Long,AccountBean> getAllAccounts() throws SQLException;
    public double TransferMoney(AccountBean from, AccountBean to,double amount) throws InsuffecientFundException, SQLException; 

}
